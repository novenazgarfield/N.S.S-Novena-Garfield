// NEXUS Landing Page JavaScript

// 操作系统检测和智能下载
class PlatformDetector {
    constructor() {
        this.platform = this.detectPlatform();
        this.init();
    }

    detectPlatform() {
        const userAgent = navigator.userAgent.toLowerCase();
        const platform = navigator.platform.toLowerCase();

        if (userAgent.includes('win') || platform.includes('win')) {
            return 'windows';
        } else if (userAgent.includes('mac') || platform.includes('mac')) {
            return 'macos';
        } else if (userAgent.includes('linux') || platform.includes('linux')) {
            return 'linux';
        } else {
            return 'windows'; // 默认
        }
    }

    init() {
        this.updateDownloadButton();
        this.highlightPlatformCard();
        this.setupDownloadHandlers();
    }

    updateDownloadButton() {
        const downloadBtn = document.getElementById('downloadBtn');
        const platformText = document.getElementById('platformText');
        
        if (!downloadBtn || !platformText) return;

        const platformConfig = {
            windows: {
                text: 'Windows',
                icon: '🪟',
                size: '~150MB'
            },
            macos: {
                text: 'macOS',
                icon: '🍎',
                size: '~160MB'
            },
            linux: {
                text: 'Linux',
                icon: '🐧',
                size: '~140MB'
            }
        };

        const config = platformConfig[this.platform];
        platformText.textContent = config.text;
        
        // 更新按钮点击事件
        downloadBtn.onclick = () => this.downloadForPlatform(this.platform);
    }

    highlightPlatformCard() {
        // 移除所有推荐标记
        document.querySelectorAll('.download-card').forEach(card => {
            card.classList.remove('recommended');
            const badge = card.querySelector('.platform-badge');
            if (badge) badge.remove();
        });

        // 为当前平台添加推荐标记
        const platformCard = document.querySelector(`[data-platform="${this.platform}"]`);
        if (platformCard) {
            platformCard.classList.add('recommended');
            
            // 添加推荐徽章
            const badge = document.createElement('div');
            badge.className = 'platform-badge';
            badge.textContent = '推荐';
            platformCard.appendChild(badge);
        }
    }

    setupDownloadHandlers() {
        document.querySelectorAll('.download-btn').forEach(btn => {
            const platform = btn.getAttribute('data-platform');
            btn.onclick = () => this.downloadForPlatform(platform);
        });
    }

    downloadForPlatform(platform) {
        // GitHub Releases 页面链接
        const baseUrl = 'https://github.com/novenazgarfield/research-workstation/releases/latest';
        
        // 显示下载提示
        this.showDownloadModal(platform);
        
        // 跳转到 GitHub Releases
        setTimeout(() => {
            window.open(baseUrl, '_blank');
        }, 1000);
    }

    showDownloadModal(platform) {
        const modal = this.createDownloadModal(platform);
        document.body.appendChild(modal);
        
        // 3秒后自动关闭
        setTimeout(() => {
            modal.remove();
        }, 3000);
    }

    createDownloadModal(platform) {
        const platformNames = {
            windows: 'Windows',
            macos: 'macOS',
            linux: 'Linux'
        };

        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            z-index: 10000;
            text-align: center;
            min-width: 300px;
        `;

        modal.innerHTML = `
            <div style="font-size: 2rem; margin-bottom: 1rem;">📦</div>
            <h3 style="margin-bottom: 0.5rem; color: #1976d2;">准备下载</h3>
            <p style="color: #666; margin-bottom: 1rem;">
                正在为您准备 ${platformNames[platform]} 版本的安装包...
            </p>
            <div style="width: 100%; height: 4px; background: #f0f0f0; border-radius: 2px; overflow: hidden;">
                <div style="width: 0%; height: 100%; background: #1976d2; border-radius: 2px; animation: progress 2s ease-in-out forwards;"></div>
            </div>
        `;

        // 添加进度条动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes progress {
                to { width: 100%; }
            }
        `;
        document.head.appendChild(style);

        return modal;
    }
}

// 平滑滚动
class SmoothScroll {
    constructor() {
        this.init();
    }

    init() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }
}

// 导航栏滚动效果
class NavbarScroll {
    constructor() {
        this.navbar = document.querySelector('.navbar');
        this.init();
    }

    init() {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                this.navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                this.navbar.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
            } else {
                this.navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                this.navbar.style.boxShadow = 'none';
            }
        });
    }
}

// 移动端导航菜单
class MobileNav {
    constructor() {
        this.toggle = document.querySelector('.nav-toggle');
        this.menu = document.querySelector('.nav-menu');
        this.init();
    }

    init() {
        if (!this.toggle || !this.menu) return;

        this.toggle.addEventListener('click', () => {
            this.toggleMenu();
        });

        // 点击菜单项时关闭菜单
        this.menu.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                this.closeMenu();
            });
        });
    }

    toggleMenu() {
        this.menu.classList.toggle('active');
        this.toggle.classList.toggle('active');
    }

    closeMenu() {
        this.menu.classList.remove('active');
        this.toggle.classList.remove('active');
    }
}

// 动画观察器
class AnimationObserver {
    constructor() {
        this.observer = new IntersectionObserver(
            (entries) => this.handleIntersection(entries),
            { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
        );
        this.init();
    }

    init() {
        // 观察需要动画的元素
        const animatedElements = document.querySelectorAll(
            '.feature-card, .download-card, .doc-card, .hero-mockup'
        );
        
        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            this.observer.observe(el);
        });
    }

    handleIntersection(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                this.observer.unobserve(entry.target);
            }
        });
    }
}

// 统计数字动画
class CounterAnimation {
    constructor() {
        this.counters = document.querySelectorAll('.stat-number');
        this.init();
    }

    init() {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.animateCounter(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.5 }
        );

        this.counters.forEach(counter => {
            observer.observe(counter);
        });
    }

    animateCounter(element) {
        const text = element.textContent;
        const hasPercent = text.includes('%');
        const hasMs = text.includes('ms');
        const isText = isNaN(parseFloat(text));

        if (isText) return; // 跳过非数字文本

        const finalValue = parseFloat(text);
        const duration = 2000;
        const steps = 60;
        const stepValue = finalValue / steps;
        const stepDuration = duration / steps;

        let currentValue = 0;
        const timer = setInterval(() => {
            currentValue += stepValue;
            if (currentValue >= finalValue) {
                currentValue = finalValue;
                clearInterval(timer);
            }

            let displayValue = Math.round(currentValue * 10) / 10;
            if (hasPercent) {
                element.textContent = displayValue + '%';
            } else if (hasMs) {
                element.textContent = '<' + Math.round(displayValue) + 'ms';
            } else {
                element.textContent = displayValue.toString();
            }
        }, stepDuration);
    }
}

// 主题切换（可选功能）
class ThemeToggle {
    constructor() {
        this.theme = localStorage.getItem('theme') || 'light';
        this.init();
    }

    init() {
        this.applyTheme();
        this.createToggleButton();
    }

    applyTheme() {
        document.documentElement.setAttribute('data-theme', this.theme);
    }

    createToggleButton() {
        const button = document.createElement('button');
        button.innerHTML = this.theme === 'light' ? '🌙' : '☀️';
        button.style.cssText = `
            position: fixed;
            bottom: 2rem;
            left: 2rem;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            background: var(--primary-color);
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: transform 0.2s ease;
            z-index: 1000;
        `;

        button.addEventListener('click', () => this.toggleTheme());
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'scale(1.1)';
        });
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'scale(1)';
        });

        document.body.appendChild(button);
    }

    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem('theme', this.theme);
        this.applyTheme();
        
        const button = document.querySelector('button[style*="fixed"]');
        if (button) {
            button.innerHTML = this.theme === 'light' ? '🌙' : '☀️';
        }
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    // 初始化所有功能
    new PlatformDetector();
    new SmoothScroll();
    new NavbarScroll();
    new MobileNav();
    new AnimationObserver();
    new CounterAnimation();
    // new ThemeToggle(); // 可选功能

    // 添加加载完成的视觉反馈
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);

    // 控制台欢迎信息
    console.log(`
    🚀 NEXUS Research Workstation
    ================================
    欢迎使用NEXUS远程指挥与控制系统！
    
    GitHub: https://github.com/novenazgarfield/research-workstation
    文档: 查看项目README了解更多信息
    
    如果您在使用过程中遇到问题，请在GitHub上提交Issue。
    ================================
    `);
});

// 错误处理
window.addEventListener('error', (e) => {
    console.error('页面错误:', e.error);
});

// 性能监控
window.addEventListener('load', () => {
    const loadTime = performance.now();
    console.log(`页面加载完成，耗时: ${Math.round(loadTime)}ms`);
});

// 导出给全局使用
window.NEXUS = {
    PlatformDetector,
    SmoothScroll,
    NavbarScroll,
    MobileNav,
    AnimationObserver,
    CounterAnimation,
    ThemeToggle
};